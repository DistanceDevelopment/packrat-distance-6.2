# general bug tests go here, they should go in another file if
# possible though

# TODO
# * check that qqplot.dff() gives a list of 4 when adjustments are used
#   * need to surpress plotting?
