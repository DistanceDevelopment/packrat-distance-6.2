[![Build Status](https://travis-ci.org/DistanceDevelopment/dsm.svg?        branch=master)](https://travis-ci.org/DistanceDevelopment/dsm)
dsm - Density surface modelling



